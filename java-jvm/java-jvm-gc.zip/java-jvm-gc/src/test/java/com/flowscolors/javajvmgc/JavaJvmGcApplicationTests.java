package com.flowscolors.javajvmgc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaJvmGcApplicationTests {

    @Test
    void contextLoads() {
    }

}
